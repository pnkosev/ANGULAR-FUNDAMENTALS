export const APP_KEY = 'kid_SkBwDHDtN'; // Kinvey APP KEY here;
export const APP_SECRET = 'c77916df72824eb0803e414f093742fd'; // Kinvey APP SECRET here;